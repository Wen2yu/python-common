#!/usr/bin/env python3
# -*- coding: utf-8 -*-

""" __module_name__ """

__author__ = 'zhangjiawen'


MAX_INT = 2**32-1
