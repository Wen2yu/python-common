# -*- coding:utf-8 -*-

# Name: base_entity
# Product_name: PyCharm
# Description:
# Author : 'zhangjiawen'
# Data : 2020-03-13 17:14

from .base_obj import BaseObj


class BaseEntity(BaseObj):
    pass
