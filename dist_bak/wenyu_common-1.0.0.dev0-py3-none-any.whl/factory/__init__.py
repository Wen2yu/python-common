# -*- coding:utf-8 -*-
# Author : 'zhangjiawen'
# Data : 2019-12-08 16:02

from .http_pool_factory import get_http_pool, remove_http_pool
from .redis_factory import get_redis
